
var msg;
msg="<p><code>The script is located in external script file called math.js</code></p>";

function addTwoNumbers(headParam,bodyParam)
{
  document.write(msg);
  return headParam+bodyParam;
 
}