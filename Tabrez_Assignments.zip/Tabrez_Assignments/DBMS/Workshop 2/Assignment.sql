/*1*/
 select country from country where country like "B%" ;
/*2*/
 select first_name from actor where last_name="berry" order by first_name asc;
/*3*/
select title,length from film where length>184 order by length,title asc;
/*4*/
select c.first_name,c.last_name,ct.city from country cu inner join city ct inner join address a inner join customer c on cu.country_id=ct.country_id and ct.city_id=a.city_id and a.address_id=c.address_id where cu.country="Canada" order by c.first_name asc;
select c.first_name,c.last_name,ct.city from country cu inner join city ct inner join address a inner join customer c on cu.country_id=ct.country_id and ct.city_id=a.city_id and a.address_id=c.address_id where cu.country="Canada" order by c.last_name asc;
/*5*/
select count(*) as Number_of_Customers_from_Brazil from country cu inner join city ci on cu.country_id=ci.country_id where cu.country="Brazil";
/*6*/
select cu.country,count(*) Total_Customers from country cu inner join city ct inner join address a inner join customer c on cu.country_id=ct.country_id and ct.city_id=a.city_id and a.address_id=c.address_id group by country having Total_Customers>20; 
/*7*/
select c.name,f.rental_duration,max(f.length) as length from film f inner join category c inner join film_category fc on f.film_id=fc.film_id and c.category_id=fc.category_id;
/*8*/
select f.title,count(actor_id) as Number_of_actors from film f inner join film_actor fa on f.film_id=fa.film_id  group by f.title having count(actor_id) >10 order by f.title limit 0,10;
/*9*/
select c.customer_id,c.first_name,c.last_name,SUM(p.amount) as amount from customer c inner join rental r inner join payment p on c.customer_id=p.customer_id and r.rental_id=p.rental_id group by c.customer_id order by amount desc limit 1;
/*10*/
select cu.country,count(*) Total_Customers from country cu inner join city ct inner join address a right join customer c on cu.country_id=ct.country_id and ct.city_id=a.city_id and a.address_id=c.address_id group by country having Total_Customers>20; 
/*The query invloves inner joins and right outer join of four tables country,city,address and customer and returns name of the country which has total number of customers more than 20 by using group by clause and filtered the results by 'having'*/