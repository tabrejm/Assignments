select curdate();
select curtime();
select now();
use mydb;
alter table student1 add DOB date;
desc student1;
select * from student1;
update student1 set dob='1995/05/11' where id=2;
update student1 set dob='1997/04/15' where id=3;
update student1 set dob='1998/02/22' where id=4;

select name ,timestampdiff(year,dob,curdate()) as age from student1;
select name ,year(dob) as year from student1;
select name ,dayofmonth(dob) as day from student1;
select name ,dayofweek(dob) as day from student1;
SELECT name,DATE_ADD(dob,INTERVAL 1 DAY) from student1;
select concat(name,dob) as user_id from student1;
select concat_ws("@",name,dob) as user_id from student1;

select @min_marks := min(marks),@max_marks := max(marks) from student1;
select * from student1 where marks in(@min_marks,@max_marks);
alter table course add foreign key(id) references student1(id);
alter table course add id int;
select * from course;
select * from student1;
insert into course(courseName,id)values("MBA",4);
update course set id=2 where courseId=3;
select * from student1 s inner join course c on s.id=c.id;
select * from student1 s right join course c on s.id=c.id;

create procedure getMarks(in student_id int,out marks int) 
BEGIN
    select id into student_id from student1 where id=student_id;
END;     






