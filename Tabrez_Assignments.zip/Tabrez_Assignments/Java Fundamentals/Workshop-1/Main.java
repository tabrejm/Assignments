package com.cybage.examples;

public class Main {

	public static void main(String[] args) {
	    
		Student s=new Student(1,"ABC",45,"Pune");
		System.out.println(s.Display());

	}

}
