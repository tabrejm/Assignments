/**
 *@author : Tabrej Mujawar
 *Assignment : Implement Queue using LinkedList.
 *Class : ImpQueueLinkedlist
 **/
package com.cybage.workshop6;

public class ImpQueueLinkedlist {
                   
             Node front;
             Node rear;
             
             public ImpQueueLinkedlist() {
				this.front=this.rear;
			}
             
             void Enqueue(int data)
             {
            	 
	             Node newnode=new Node(data);
	             
	             if(this.rear==null)
	             {
	            	 this.front=this.rear=newnode;
	            	 return;
	             }
	             
	             this.rear.next=newnode;
	             this.rear=newnode;
	             
             }
             
             void Dequeue()
             {
            	 
            	 if(this.front==null)
            	 {
            		 return;
            	 }
            	 Node newnode=this.front;
            	 this.front=this.front.next;
            	 
            	 if(this.front==null)
            	 {
            		 this.rear=null;
            	 }
            	 
             }

	public static void main(String[] args)
	{
		 ImpQueueLinkedlist queue=new ImpQueueLinkedlist();
		    queue.Enqueue(10);
		    queue.Enqueue(20);
		    queue.Enqueue(30);
		    queue.Dequeue();
		    queue.Enqueue(40);
		    queue.Dequeue();
		    queue.Enqueue(50);
		    System.out.println("Queue Front = "+queue.front.data);
		    System.out.println("Queue Rear = "+queue.rear.data);
		
	}

}
