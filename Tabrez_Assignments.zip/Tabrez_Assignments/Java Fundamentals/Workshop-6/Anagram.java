/**
 *@author : Tabrej Mujawar
 * Assignment : 1.	WAP to Check whether two strings are anagram of each other
 * Class : Anagram
 **/
package com.cybage.workshop6;

import java.util.Arrays;

public class Anagram {
	
	public void checkAnagram(String s1,String s2)
	{
		String string1=s1.replaceAll("\\s","");
		String string2=s2.replaceAll("\\s","");
		boolean status=true;
		
		if(string1.length()!=string2.length())
		{
			status=false;
		}
		else
		{
			char[] arrayString1=string1.toLowerCase().toCharArray();
			char[] arrayString2=string2.toLowerCase().toCharArray();
			Arrays.sort(arrayString1);
			Arrays.sort(arrayString2);
			status=Arrays.equals(arrayString1,arrayString2);
		}
		
		if(status)
		{
			System.out.println("Both strings are anagrams of each other");
		}
		else
			System.out.println("Not the anagrams of each other");
		
	}

	public static void main(String[] args) {
		
                  Anagram anagram=new Anagram();
                  anagram.checkAnagram("Race","Care");
	}

}
