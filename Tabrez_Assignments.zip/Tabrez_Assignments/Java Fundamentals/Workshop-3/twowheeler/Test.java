package twowheeler;

import automobile.Vehicle;

public class Test {

	public static void main(String[] args) {
		Hero v1=new Hero();
		Honda v2=new Honda();
		System.out.println("Hero details : ");
		System.out.println(v1.modelName());
		System.out.println(v1.registrationNumber());
		System.out.println(v1.ownerName());
		System.out.println("Speed = "+v1.speed());
		v1.radio();
		
		System.out.println("\nHonda details : ");
		System.out.println(v2.modelName());
		System.out.println(v2.registrationNumber());
		System.out.println(v2.ownerName());
		System.out.println("Speed = "+v2.speed());
		v2.cdplayer();
	}

}
