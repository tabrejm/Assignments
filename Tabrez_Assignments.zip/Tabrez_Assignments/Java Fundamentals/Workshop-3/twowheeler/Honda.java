package twowheeler;

import automobile.Vehicle;

public class Honda extends Vehicle {

	@Override
	public String modelName() {
		return "Model name = Honda Dio";
	}

	@Override
	public String registrationNumber() {
		// TODO Auto-generated method stub
		return "Registeration number = 4656623";
	}

	@Override
	public String ownerName() {
		// TODO Auto-generated method stub
		return "Owner name = PQR";
	}
	
	public int speed() 
	{
		return 120;
	}
	
	public void cdplayer() 
	{
		System.out.println("Provides facility to control the cd player device which is available in the car");
	}

}
