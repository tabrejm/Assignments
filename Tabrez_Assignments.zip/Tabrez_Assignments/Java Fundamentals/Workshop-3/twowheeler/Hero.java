package twowheeler;

import automobile.Vehicle;

public class Hero extends Vehicle {

	@Override
	public String modelName() {
		return "Model name = Hero Splender";
	}

	@Override
	public String registrationNumber() {
		// TODO Auto-generated method stub
		return "Registeration number = 1236565";
	}

	@Override
	public String ownerName() {
		// TODO Auto-generated method stub
		return "Owner name = ABC";
	}
	
	public int speed() 
	{
		return 100;
	}
	
	public void radio() 
	{
		System.out.println("Provides facility to control the radio device ");
	}
	

}
