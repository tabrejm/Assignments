package day4;


public class Main {

	public static void main(String[] args) {
		 Rectangle r=new Rectangle(10,20);
		 r.Area();
		Triangle t=new Triangle(40, 60);
		 t.Area();

	}

}
