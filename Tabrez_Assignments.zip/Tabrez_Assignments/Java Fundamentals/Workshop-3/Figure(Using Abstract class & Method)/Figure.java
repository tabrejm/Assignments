package day4;


 public abstract class Figure {
	
	   double a;
	   double b;

  public Figure(double a, double b) {
		
		this.a = a;
		this.b = b;
		
	}
	  
	public abstract void Area();
	


}


