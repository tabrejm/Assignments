package day4;

public class LongestCommonSubsequence {
	
	public String findLongestCommonSequence(String s1, String s2)
	{
	
		int[][] arr=new int[s1.length()+1][s2.length()+1];
		 
		for(int i=s1.length()-1;i>=0;i--)
		 {
		     for(int j=s2.length()-1;j>=0;j--)
		     {
		    	  if(s1.charAt(i)==s2.charAt(j))
		    	  {
		    		  arr[i][j]=arr[i+1][j+1]+1;
		    	  }
		    	  else
		    	  {
		    		  arr[i][j]=Math.max(arr[i+1][j],arr[i][j+1]);
		    	  }
		     }
		     
		     
		 }
		
		 int i=0;
	     int j=0;
	     StringBuffer sb=new StringBuffer();
	     
	     while(i<s1.length() && j<s2.length())
	     {
	          if(s1.charAt(i)==s2.charAt(j))
	          {
	        	  sb.append(s1.charAt(i));
	        	  i++;
	        	  j++;
	          }
	          else if(arr[i+1][j]>=arr[i][j+1])
	        	  i++;
	          else
	        	  j++;
	     }
	     return sb.toString();
	     
		
	}
	
	public static void main(String[] args) {
		
		 String s1="Welcome";
		 String s2="Program";
		 
		 LongestCommonSubsequence l=new LongestCommonSubsequence();
		 System.out.println("Longest common subsequence = "+l.findLongestCommonSequence(s1, s2));
		
	}

}
