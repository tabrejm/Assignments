package day4;

public class RemoveUppercaseNumericChar {

	public static void main(String[] args) {
		
		   String s="Welcome to @Java Programming 8";
		   char[] c=s.toCharArray();
		   String result=s.replaceAll("[^a-z]","");
		  
		   System.out.println("Result = "+result);

	}

}
