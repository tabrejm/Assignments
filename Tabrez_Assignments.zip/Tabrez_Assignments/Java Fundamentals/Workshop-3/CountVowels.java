package day4;

public class CountVowels {

	public static void main(String[] args) {
		
		 String s="Welcome";
		 char[] c=s.toCharArray();
		 int count=0;
		 for(int i=0;i<c.length;i++)
		 {
			 if(c[i]=='a' || c[i]=='e' || c[i]=='i' || c[i]=='o' || c[i]=='u')
			 {
				 count++;
			 }
		 }
		 System.out.println("Number of vowels in string = "+count);
	}

}
