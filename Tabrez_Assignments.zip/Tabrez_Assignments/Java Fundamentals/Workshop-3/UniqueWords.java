package day4;

import java.util.Arrays;

public class UniqueWords {

	public static void main(String[] args) {
	       
		   String s="Good morning have a nice day have a nice weekend";
	       String[] words=s.split(" ");
	      
	       int count=0;
	       for(int i=0;i<words.length;i++)
	       {
	    	   count=1;
	    	   
	    	   for(int j=i+1;j<words.length;j++)
	    	   {
	    		   if(words[i].equals(words[j]))
	    		   {
	    			   count++;
	    			  words[j]="";
	    		   }
	    	   }
	    	   if(count==1 && words[i]!="")
	    	   {
	    		   System.out.print(words[i]+" ");
	    	   }
	    	
	    	  
	       }
	      
	       
	}

}
