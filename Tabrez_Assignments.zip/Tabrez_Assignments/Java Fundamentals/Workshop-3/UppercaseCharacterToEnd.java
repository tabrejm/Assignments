package day4;

public class UppercaseCharacterToEnd {

	public static void main(String[] args) {
		
		String s="JaVa";
		String ns="";
		for(int i=0;i<s.length();i++)
		{
			if(Character.isUpperCase(s.charAt(i)))
			{
				ns=ns+s.charAt(i);
				s=s.replace(String.valueOf(s.charAt(i)),"");
			}
			
		}
		s=s+ns;
		System.out.println(s);
	}

}
