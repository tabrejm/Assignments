package day4;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternString {

	 public String[] patternMatches(String[] s)
	 {
		 Pattern p=Pattern.compile("a.{2}$");
		 String[] arr=new String[s.length];
		 int count=0; 
		 for(int i=0;i<s.length;i++)
		 {
			Matcher m=p.matcher(s[i]);
			if(m.matches())
			{
				arr[count++]=s[i];
			 }
		 }
	
		 String[] a=new String[count];
		 int c=0;
		 for(int j=0;j<s.length;j++)
		 {
			 if(arr[j]!=null)
			 {
				 a[c++]=arr[j];
			 }
		 }
		 return a;
	 }
	
	public static void main(String[] args) {
	         
		    String[] list=new String[5];
		    list[0]="Welcome";
		    list[1]="how";
		    list[2]="are";
		    list[3]="you";
		    list[4]="all";
		    
		    PatternString p=new PatternString();
		    System.out.println("Result = "+Arrays.toString(p.patternMatches(list)));
		   

	}

}
