package day4;

public class LongestPalindromeSubstring {
	
	    public String longestPalindromeSubs(String s)
	    {
	    	if(s==null)
	    	{
	    		return "Invalid string";
	    	}
	    	if(s.length()==1)
	    	{
	    		return s;
	    	}
	    	
	    	String l=s.substring(0,1);
	    	for(int i=0;i<s.length();i++)
	    	{
	    		 String temp=check(s,i,i);
		    		 if(temp.length()>l.length())
		    		 {
		    			 l=temp;
		    		 }
	    			temp=check(s,i,i+1);
					 if(temp.length()>l.length())
					 {
						 l=temp;
					 }
	    			
	    	}
	    	return l;
	    }
	    
	    public String check(String s,int b,int e)
	    {
	    	while(b>=0 && e<=s.length()-1 && s.charAt(b)==s.charAt(e))
	    	{
	    		b--;
	    		e++;
	    	}
	    	return s.substring(b+1,e);
	    }

	public static void main(String[] args) {
		    
		LongestPalindromeSubstring l=new LongestPalindromeSubstring();
		String s="Java";
		
		System.out.println("Longest Palindrome substring of given string = "+l.longestPalindromeSubs(s));
	
	
		
      
	}

}
