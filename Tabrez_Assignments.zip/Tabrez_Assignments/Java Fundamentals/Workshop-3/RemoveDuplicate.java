package day4;

public class RemoveDuplicate {

	public static void main(String[] args) {
	   
		 String s="Hi welcome welcome to all";
		String[] arr=s.split(" ");
		 String result="";
		 for(int i=0;i<arr.length;i++)
		 {
			 for(int j=i+1;j<arr.length;j++)
			 {
				 if(arr[j].equals(arr[i]))
				 {
					  result=s.replaceFirst(arr[j],"");
				 }
			 }
		 }
		 
         System.out.println(result);
	}

}
