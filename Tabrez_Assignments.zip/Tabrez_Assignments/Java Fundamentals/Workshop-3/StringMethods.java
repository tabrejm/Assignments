package day4;

public class StringMethods {

	public static void main(String[] args) {
		String s="Welcome";
		System.out.println("Character : "+s.charAt(1));
		System.out.println("Index = "+s.indexOf('m'));
		System.out.println("Substring = "+s.substring(1, 4));
		System.out.println("Uppercase of string = "+s.toUpperCase());
		System.out.println("Lowercase of string = "+s.toLowerCase());
		
		String s1="hi";
		String s2="hi";
		String s3=new String("hi");
		
		System.out.println("Content equality : "+s1.equals(s3));
		System.out.println("Reference equality : "+(s1==s3));
		System.out.println("Reference equality : "+(s1==s2));
	
		
	}

}
