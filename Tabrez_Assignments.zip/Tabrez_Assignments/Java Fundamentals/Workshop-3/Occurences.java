package day4;

public class Occurences {

	public static void main(String[] args) {
		   
		   String s="Welcome";
		   int[] count=new int[256];
		   char[] c=s.toCharArray();
		   boolean flag=false;
		 
		   for(int a=0;a<c.length;a++)
		   {
			   count[c[a]]++;
		   }
		   
		   for(int i=0;i<c.length;i++)
		   {
			   
			   int occ=0;
			   for(int j=0;j<=i;j++)
			   {
				   if(c[i]==c[j])
				   {
					   occ++;
				   }
			   }
			   if(occ==1)
			   {
			   System.out.println(c[i]+" = "+count[c[i]]);
			   }
		   }

	}

}
