package day4;

import java.util.Scanner;

public class Dictionary {

	public static void main(String[] args) {
		String[] dict= {"Hello","Java","From","Hi","Jhon" };
		System.out.println("Number of words");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		String inputs[]=new String[size];
		boolean flag=false;
		for(int i=0;i<size;i++)
		{
			System.out.println("Enter input "+(i+1));
			inputs[i]=sc.next();
		}
		
		for(int j=0;j<size;j++)
		{
			for(int k=0;k<dict.length;k++)
			{
				if(inputs[j].equals(dict[k]))
				{
					flag=true;
				}
			}
			if(!flag)
			{
				break;
			}
		}
		if(flag)
		{
			System.out.println("YES");
		}
		else
		  System.out.println("NO");

	}

}
