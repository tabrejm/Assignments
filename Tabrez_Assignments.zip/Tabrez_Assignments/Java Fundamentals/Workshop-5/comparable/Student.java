/**
 *@author : Tabrej Mujawar
 *Assignment : Create a class Student.In Main program create a list of students and sort it according to student name(Using comparable) . 
 
 *Class : Student
 **/
package comparable;

public class Student implements Comparable<Student>{
	
	   private int studentId;
	   private String name;
	   private String location;
	   
	   public Student(int studentId, String name, String location) {
			super();
			this.studentId = studentId;
			this.name = name;
			this.location = location;
		}
	
	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", location=" + location + "]";
	}

	@Override
	public int compareTo(Student s) {
		return this.name.compareTo(s.getName());
	}

	
	
}
