/**
 *@author : Tabrej Mujawar
 *Assignment : Create a class Student.In Main program create a list of students and sort it according to student name(Using comparable) . 
 *Class : TestStudent
 **/
package comparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TestStudent {

	public static void main(String[] args) {
		   
		   List<Student> students=new ArrayList<>();
		    students.add(new Student(1,"Peter","California"));
		    students.add(new Student(2,"Jack","Bangalore"));
		    students.add(new Student(3,"Alice","Pune"));
		    
		    System.out.println("Original student list : ");
            students.forEach((i)->System.out.println(i));
            System.out.println();
            
            Collections.sort(students);
            System.out.println("Sorted student list according to names : ");
            students.forEach((i)->System.out.println(i));   
		    

	}

}
