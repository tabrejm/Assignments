/**
 *@author : Tabrej Mujawar
 * Assignment : Write a Java Program to iterate HashMap using While and advance for loop.
 * Class : IterateHashMap
 **/
package com.cybage.workshop5;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class IterateHashMap {

	public static void main(String[] args) {
		
		Map<Integer,String> map=new HashMap<>();
		map.put(1,"Pune");
		map.put(2,"Bangalore");
		map.put(3,"Mumbai");
		map.put(4,"Hyderabad");
		map.put(5,"Chennai");
		
		Iterator<Integer> iterator=map.keySet().iterator();
		
		while(iterator.hasNext())
		{
			int key=iterator.next();
			System.out.println("Perference option "+key+ " = "+map.get(key));
		}
		System.out.println();
       
		for(Map.Entry<Integer,String> perference:map.entrySet())
		{
			System.out.println("Perference option "+perference);
		}
			
		

	}

}
