/**
 *@author : Tabrej Mujawar
 * Assignment :WAP to implement the concept of Stack using LinkedList.
 * Class : Node
 **/
package com.cybage.workshop5;

public class LinkedListStack {

	        private Node top;
	        private int size;
	        
	        public LinkedListStack() {
				this.top=null;
				this.size=0;
			}
	
	        public void push(int data)
	        {
	        	Node newnode=new Node(data);
	        	newnode.setNext(top);
	        	top=newnode;
	        	size++;
	        	System.out.println("Inserted");
	        }
	        
	      public int pop()
	      {
	    	  if(top==null)
	    	  {
	    		
	    		  System.out.println("Empty stack");
	    		  return 0;
	    	  }
	    	  Node node=top;
	    	  top=top.getNext();
	    	  size--;
	    	  return node.getData();
	    	  
	      }
	        
	      public int peak()
	      {
	    	  if(top==null)
	    	  {
	    		  {
	  	    		
		    		  System.out.println("Empty stack");
		    		  return 0;
		    	  }
	    	  }
	    	  return top.getData();
	      }
	       public Node getTop() {
				return top;
			}

			public void setTop(Node top) {
				this.top = top;
			}
			
			public void display()
			{
				System.out.println("Stack :");
				Node temp=top;
				while(temp!=null)
				{
					System.out.println(temp.getData());
					temp=temp.getNext();
				}
			}
			
			

	public static void main(String[] args) {
		
		    LinkedListStack stack=new LinkedListStack();
		    stack.push(10);
		    stack.push(20);
		    stack.push(30);
		    stack.push(40);
		    
		    stack.display();
		  
		    System.out.println("Popped = "+stack.pop());
		    System.out.println("Popped = "+stack.pop());
		    
		    stack.display();
		    System.out.println("Peak = "+stack.peak());
	}

}
