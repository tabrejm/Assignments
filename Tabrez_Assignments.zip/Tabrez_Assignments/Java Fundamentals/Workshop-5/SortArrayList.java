/**
 *@author : Tabrej Mujawar
 * Assignment : Write a Java program to sort a given ArrayList
 * Class : SortArrayList
 **/
package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortArrayList {

	public static void main(String[] args) {
		  
		 List<Integer> list=new ArrayList<>();
		  list.add(50000);
		  list.add(45000);
		  list.add(65000);
		  list.add(35000);
		  list.add(55000);
		  
		  System.out.println("Original list = "+list);
		  Collections.sort(list);
		  System.out.println("Sorted list = "+list);

	}

}
