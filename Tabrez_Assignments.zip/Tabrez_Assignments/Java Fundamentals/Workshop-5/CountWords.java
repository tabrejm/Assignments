/**
 *@author : Tabrej Mujawar
 * Assignment : Write a Java Program to count the number of words in a string using HashMap.
 * Class : CountWords
 **/
package com.cybage.workshop5;

import java.util.HashMap;
import java.util.Map;

public class CountWords {

	public static void main(String[] args) {
		
		int count=0;
		Map<String,Integer> map=new HashMap<>();
		String s="Welcome to Java Programming";
		String[] words=s.split(" ");
		
		for(String str:words )
		{
			map.put(str,count++);
		}
		
		System.out.println("Number of words in given string = "+map.size());

	}

}
