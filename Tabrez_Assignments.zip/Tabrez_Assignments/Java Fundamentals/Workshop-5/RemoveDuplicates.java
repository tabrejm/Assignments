/**
 *@author : Tabrej Mujawar
 * Assignment :WAP to remove duplicates from a given list.
 * Class : RemoveDuplicates
 **/
package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RemoveDuplicates {

	public static void main(String[] args) {
		
		List<String> nameList=new ArrayList<>();
		nameList.add("John");
		nameList.add("Williams");
		nameList.add("John");
		nameList.add("Peter");
		nameList.add("George");
		
		System.out.println(" Name list : "+nameList);
		Iterator<String> iterator=nameList.iterator();
		List<String> updatedNameList=new ArrayList<>();
		while(iterator.hasNext())
		{
			String name=iterator.next();
			if(!updatedNameList.contains(name))
			{
				updatedNameList.add(name);
			}
		}
		
		System.out.println("Updated list after Removing duplicates :"+updatedNameList);

	}

}
