/**
 *@author : Tabrej Mujawar
 * Assignment :Program to add, retrieve & remove element from ArrayList.
 * Class : AddRetrieveRemoveList
 **/
package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.List;

public class AddRetrieveRemoveList {

	public static void main(String[] args) {
		   
		List<String> fruits=new ArrayList<>();
		fruits.add("Mango");
		fruits.add("Watermelon");
		fruits.add("Orange");
		fruits.add("Apple");
		fruits.add("Pineapple");
		
		System.out.println("Retrieving elements from list : ");
		System.out.println(fruits.get(0));
		System.out.println(fruits.get(1));
		System.out.println(fruits.get(2));
		System.out.println(fruits.get(3));
		System.out.println(fruits.get(4)+"\n");
		
		System.out.println("Removing elements from list : ");
		fruits.remove(1);
		fruits.remove("Orange");
			
		System.out.println(fruits);

	}

}
