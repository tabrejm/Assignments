/**
 *@author : Tabrej Mujawar
 * Assignment : Write a program to implement LinkedList and perform different operations on it.
 * Class : LinkedList
 **/
package com.cybage.workshop5;

import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {
	
		 List<String> games=new LinkedList<>();
		 games.add("Cricket");
		 games.add("Football");
		 games.add("Basketball");
		 games.add("Hockey");
		 games.add("Badminton");
		 
		 System.out.println("Games : "+games); 
		 System.out.println(games.remove(3)+" removed");
		 System.out.println("Games : "+games);
		 System.out.println(games.set(2,"Table tennis")+" has been replaced by "+games.get(2));
		 System.out.println(games);
	  
		 
		 
		 

	}

}
