/**
 *@author : Tabrej Mujawar
 *Assignment : Create a class Student.In Main program create a list of students and sort it according Implement above program Using Comparator.
             1. perform sorting according to name.
             2. perform Sorting according to rollNo.
             3. perform Sorting according to marks.
 *Class : TestStudent
 **/
package comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestStudent {

	public static void main(String[] args) {
		   
		   List<Student> students=new ArrayList<>();
		    students.add(new Student(4,"Peter","California",95));
		    students.add(new Student(1,"Jack","Bangalore",85));
		    students.add(new Student(2,"Alice","Pune",91));
		    
		    System.out.println("Original student list : ");
            students.forEach((i)->System.out.println(i));
            System.out.println();
            
            Collections.sort(students,new Comparator<Student>()
            		{
						@Override
						public int compare(Student student1, Student student2) {
							return student1.getName().compareTo(student2.getName());
						}  
            		}
            		);
            System.out.println("Sorted student list according to there names : ");
            students.forEach((i)->System.out.println(i)); 
            System.out.println(); 
		    
            Collections.sort(students,new Comparator<Student>()
    		{
				@Override
				public int compare(Student student1, Student student2) {
					  if(student1.getStudentId()>student2.getStudentId())
					  {
						  return 1;
					  }
					  else if(student1.getStudentId()<student2.getStudentId())
					  {
						  return -1;
					  }
					  else
						  return 0;
				}  
    		}
    		);
		    System.out.println("Sorted student list according to there roll number : ");
		    students.forEach((i)->System.out.println(i));   
		    System.out.println();
		    
		    Collections.sort(students,new Comparator<Student>()
    		{
				@Override
				public int compare(Student student1, Student student2) {
					  if(student1.getMarks()>student2.getMarks())
					  {
						  return 1;
					  }
					  else if(student1.getMarks()<student2.getMarks())
					  {
						  return -1;
					  }
					  else
						  return 0;
				}  
    		}
    		);
		    System.out.println("Sorted student list according to there marks : ");
		    students.forEach((i)->System.out.println(i));   
		    
		    
			}

}
