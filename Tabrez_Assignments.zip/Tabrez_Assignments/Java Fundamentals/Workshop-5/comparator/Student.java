/**
 *@author : Tabrej Mujawar
 *Assignment : Create a class Student.In Main program create a list of students and sort it according Implement above program Using Comparator.
             1. perform sorting according to name.
             2. perform Sorting according to rollNo.
             3. perform Sorting according to marks.
 *Class : Student
 **/
package comparator;

public class Student {
	
	   private int studentId;
	   private String name;
	   private String location;
	   private double marks;
	   
	   public Student(int studentId, String name, String location,double marks) {
			super();
			this.studentId = studentId;
			this.name = name;
			this.location = location;
			this.marks=marks;
		}
	
	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", location=" + location + ", marks=" + marks
				+ "]";
	}

	

	

	
	
}
