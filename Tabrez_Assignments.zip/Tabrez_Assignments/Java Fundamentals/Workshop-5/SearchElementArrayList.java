/**
 *@author : Tabrej Mujawar
 * Assignment : Given an element write a program to check if that element(value) exists in ArrayList or not.
 * Class : SearchElementArrayList
 **/
package com.cybage.workshop5;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SearchElementArrayList {

	public static void main(String[] args) {
		 
		 Scanner sc=new Scanner(System.in);
		 List<String> games=new ArrayList<>();
		 games.add("Cricket");
		 games.add("Football");
		 games.add("Basketball");
		 games.add("Hockey");
		 games.add("Badminton");
		 
		 System.out.println("Enter element to search in list");
		 String element=sc.next();
         
		 if(games.contains(element))
         {
            System.out.println("Element exists in the list");	 
         }
		 else
			 System.out.println("Not exists");
		 
	}

}
