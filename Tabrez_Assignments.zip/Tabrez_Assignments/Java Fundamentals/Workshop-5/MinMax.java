/**
 *@author : Tabrej Mujawar
 * Assignment : Write a program to find Min and Max in a List in Java(Collections.min() &max()).
 * Class : MinMax
 **/
package com.cybage.workshop5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MinMax {

	public static void main(String[] args) {
	         
		  List<Integer> list=new ArrayList<>();
		  list.add(15000);
		  list.add(45000);
		  list.add(65000);
		  list.add(35000);
		  list.add(55000);
		  
		  System.out.println("Minimum = "+Collections.min(list) );
		  System.out.println("Maximum = "+Collections.max(list));
  
	}

}
