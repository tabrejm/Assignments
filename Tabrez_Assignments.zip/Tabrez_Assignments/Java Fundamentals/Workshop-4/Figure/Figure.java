/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: Figure
**/
package com.cybage.workshop4;

public interface Figure {
	
	  public double CalculateArea(double a);
      public double CalculatePerimeter(double p);
     
}
