/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: Sphere
**/
package com.cybage.workshop4;

public class Sphere implements Figure {
	double PI=3.14;
	@Override
	public double CalculateArea(double radius) {
		
         return (PI*radius*radius);
	}

	@Override
	public double CalculatePerimeter(double radius) {
	
		return (2*PI*radius);
	}

	public double CalculateSurfaceArea(double radius) {
		
		return (4*PI*radius*radius);
	}

	public double CalculateVolume(double radius) {
	
		return (4/3*PI*radius*radius*radius);
	}

}
