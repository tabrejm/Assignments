/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: TestFigure
**/
package com.cybage.workshop4;

public class TestFigure {
	
	public static void main(String[] args)
	{
	      Figure circle=new Circle();
	      System.out.println("Circle calculations :");
		  System.out.println("Area  = "+circle.CalculateArea(4));
		  System.out.println("Perimeter = "+circle.CalculatePerimeter(4)+"\n");
		  
		  Figure square=new Square();
	      System.out.println("Square calculations :");
		  System.out.println("Area  = "+square.CalculateArea(12));
		  System.out.println("Perimeter = "+square.CalculatePerimeter(12)+"\n");
		  
		  Sphere sphere=new Sphere();
	      System.out.println("Sphere calculations :");
		  System.out.println("Area  = "+sphere.CalculateArea(5));
		  System.out.println("Perimeter = "+sphere.CalculatePerimeter(5));
		  System.out.println("Surface Area = "+sphere.CalculateSurfaceArea(5));
		  System.out.println("Volume = "+sphere.CalculateVolume(5)+"\n");
		  
		  Cuboid cuboid=new Cuboid();
		  System.out.println("Cuboid calculations :");
		  System.out.println("Area  = "+cuboid.CalculateArea(4));
		  System.out.println("Perimeter = "+cuboid.CalculatePerimeter(4));
		  System.out.println("Surface Area = "+cuboid.CalculateSurfaceArea(4));
		  System.out.println("Volume = "+cuboid.CalculateVolume(4));
		  
		  
		  
		  
	}	  

}
