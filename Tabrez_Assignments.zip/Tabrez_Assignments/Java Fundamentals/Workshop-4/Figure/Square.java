/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: Square
**/
package com.cybage.workshop4;

public class Square implements Figure {

	@Override
	public double CalculateArea(double side) {
		
		return (side*side);
	}

	@Override
	public double CalculatePerimeter(double side) {
	
		return (4*side);
	}

}
