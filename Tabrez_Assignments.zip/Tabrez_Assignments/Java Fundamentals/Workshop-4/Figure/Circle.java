/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: Circle
**/
package com.cybage.workshop4;

public  class Circle implements Figure {
    
	  double PI=3.14;
	
	@Override
	public double CalculateArea(double radius) {
		  
		  return (PI*radius*radius);
	}

	@Override
	public double CalculatePerimeter(double radius) {
		
		return (2*PI*radius);
	}

}
