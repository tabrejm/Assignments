/**
@author: Tabrej Mujawar
Assignment: Write program to calculate Area and volume depending upon type of figure by implementing interfaces for CalculateArea and CalculateVolume
Class: Cuboid
**/
package com.cybage.workshop4;

public class Cuboid implements Figure {

	@Override
	public double CalculateArea(double side) {
	
		return (side*side);
	}

	public double CalculateVolume(double side) {
		
		return (side*side*side);
	}

	@Override
	public double CalculatePerimeter(double side) {
		
		return (4*side);
	}

	public double CalculateSurfaceArea(double side) {
	
		return (6*side*side);
	}

}
