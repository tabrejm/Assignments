package com.cybage.workshop4;
import static java.lang.Math.*;

public class StaticMethods {
	
	
	public static void main(String[] args)
	{
		 System.out.println("Square root : "+sqrt(25));
		 System.out.println("Addition  : "+addExact(10,40));
		 System.out.println("Substraction  : "+addExact(150,50));
		 System.out.println("Multiplication : "+multiplyExact(10, 40));
		 System.out.println("Maximum : "+max(400,200));
		 System.out.println("Minimum : "+min(5,4));
		 System.out.println("Round : "+round(425.40));
	}

}
