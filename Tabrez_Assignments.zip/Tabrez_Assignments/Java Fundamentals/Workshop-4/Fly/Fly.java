/**
 @author: Tabrej Mujawar
 Assignment: Create one interface Fly. Create two implementing classes Bird and Airplane. Inside Main Method Create objects of this two classes. Use The concept of Run Time Polymorphism.
 Interface: Fly
**/
package com.cybage.workshop4;

public interface Fly {
	
	 void fly();
   
}
