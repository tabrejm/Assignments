/**
 @author: Tabrej Mujawar
 Assignment: There is an animal class which has the common characteristics of all animals. Dog, Horse, Cat are animals(sub-class). Each can shout, but each shout is different. Use polymorphism to create objects of same and using an animal variable, make each of the animals shout.
 Class: Animal
**/
package com.cybage.workshop4;

public class Animal {
	  
	 
	  public void shout()
	  {
		  System.out.println("Animal shout");
	  }
	      
	

}



