/**
 @author: Tabrej Mujawar
 Assignment: WAP to find given no is Armstrong or not.
 Class: Armstrong
**/
package com.cybage.workshop4;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		    int sum=0;
		    int remainder=0;
		    
		    System.out.println("Enter number");
            Scanner sc=new Scanner(System.in);
            int number=sc.nextInt();
            int orginal=number;
            while(number!=0)
            {
            	 remainder=number%10;
            	 sum=sum+(remainder*remainder*remainder);
            	 number=number/10;	
            }
            
            if(orginal==sum)
            {
            	System.out.println("Armstrong number");
            }
            else
            	System.out.println("Not a Armstrong number");
            
	}

}
