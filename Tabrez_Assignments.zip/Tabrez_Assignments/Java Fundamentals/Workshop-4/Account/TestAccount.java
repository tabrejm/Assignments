/**
@author: Tabrej Mujawar
Assignment: Create classes as shown in the UML diagram given above and test your classes
Class: TestAccount
**/
package com.cybage.workshop4;

public class TestAccount {

	public static void main(String[] args) {
		
		Account savingsAccount=new SavingsAccount(5000,10);
		System.out.println("Savings account transactions : ");
		System.out.println("Balance = "+savingsAccount.getBalance());
		System.out.println(savingsAccount.Deposit(500));
		System.out.println("Money deposited successfully");
		System.out.println("Balance = "+savingsAccount.getBalance());
		System.out.println(savingsAccount.Withdraw(1000));
		System.out.println("Money withdrawn successfully");
		System.out.println("Balance = "+savingsAccount.getBalance()+"\n");
		
		Account checkingAccount=new CheckingAccount(1000,2000);
		System.out.println("Checking account transactions : ");
		System.out.println("Balance = "+checkingAccount.getBalance());
		System.out.println(checkingAccount.Withdraw(500));
		System.out.println("Balance = "+checkingAccount.getBalance());

	}

}
