/**
@author: Tabrej Mujawar
Assignment: Create classes as shown in the UML diagram given above and test your classes
Class: Account
**/
package com.cybage.workshop4;

public abstract class Account {
	
	 double balance;

	public Account(double balance) {
		this.balance = balance;
	}
	
	public abstract double getBalance();
	
	public abstract boolean Deposit(double amount);
	
	public abstract boolean Withdraw(double withdrawAmount);


}
