/**
@author: Tabrej Mujawar
Assignment: Create classes as shown in the UML diagram given above and test your classes
Class: CheckingAccount
**/
package com.cybage.workshop4;

public class CheckingAccount extends Account {
    
	  double overdraftAmount;
	
	public CheckingAccount(double balance,double overdraftAmount) {
		super(balance=balance-overdraftAmount);
	}
	
	public CheckingAccount(double balance) {
		super(balance);
		
	}

	@Override
	public double getBalance() {
		
		return this.balance;
	}

	@Override
	public boolean Deposit(double amount) {
		this.balance=balance+amount;
		return true;
	}

	@Override
	public boolean Withdraw(double withdrawAmount) {
		// TODO Auto-generated method stub
		return false;
	}

}
