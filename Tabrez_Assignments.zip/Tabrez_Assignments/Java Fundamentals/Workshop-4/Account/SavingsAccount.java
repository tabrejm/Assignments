/**
@author: Tabrej Mujawar
Assignment: Create classes as shown in the UML diagram given above and test your classes
Class: SavingsAccount
**/
package com.cybage.workshop4;

public class SavingsAccount extends Account {
   
	double interestRate;
	public SavingsAccount(double balance,double interestRate) {
		super(balance=balance+(balance/interestRate));
	}
	@Override
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
	@Override
	public boolean Deposit(double amount) {
		balance=balance+amount;
		return true;
	}
	@Override
	public boolean Withdraw(double withdrawAmount) {
		if(withdrawAmount<this.balance)
		{
		this.balance=this.balance-withdrawAmount;
		 return true;
		}
	  return false;	
	}

}
