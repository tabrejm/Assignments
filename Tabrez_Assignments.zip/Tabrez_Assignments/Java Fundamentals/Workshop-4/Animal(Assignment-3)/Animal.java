/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Class: Animal
**/
package com.animal;

public abstract class Animal {
    
	   int legs;
	   
    public Animal()
    {
    	System.out.println("In Animal class");
    }
	   
	public Animal(int legs) {
		this.legs = legs;
	}
	  
	 void walk()
	 {
		 
	 };
	 abstract void eat();
	   
	   
	   
}
