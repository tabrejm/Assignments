/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Class: Fish
**/
package com.animal;

public class Fish extends Animal implements Pet {
	
	 String name;
	 
	 public Fish() {
		System.out.println("In Fish class");
	}

	public Fish(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setName(String name) {
		this.name=name;
		
	}

	@Override
	public void play() {
		System.out.println("Fish plays");
		
	}

	@Override
	void walk() {
		System.out.println("Fish dosen't walks");
		
	}

	@Override
	void eat() {
		System.out.println("Fish eats insects");
		
	}
	
	
	 

}
