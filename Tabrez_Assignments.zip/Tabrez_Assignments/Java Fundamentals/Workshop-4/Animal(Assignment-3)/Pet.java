/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Interface: Pet
**/
package com.animal;

public interface Pet {

	 String getName();
	 void setName(String name);
	 void play();
}
