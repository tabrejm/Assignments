/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Class: Cat
**/
package com.animal;

public class Cat extends Animal implements Pet {
	   
	   String name;
	
      public Cat() {
		System.out.println("In cat class");
	}
   
  public Cat(String name) {
		super();
		this.name = name;
	}


@Override
void eat() {
	System.out.println("Cat eats mouse");
}

@Override
public String getName() {
	// TODO Auto-generated method stub
	return name;
}

@Override
public void setName(String name) {
	this.name=name;
}

@Override
public void play() {
	System.out.println("Cat plays");
	
}



}