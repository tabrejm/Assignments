/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Class: Spider
**/
package com.animal;

public class Spider extends Animal {

	public Spider() {
		System.out.println("In Spider class");
	}

	@Override
	void eat() {
	   System.out.println("Spider eats small insects");

	}

	

}
