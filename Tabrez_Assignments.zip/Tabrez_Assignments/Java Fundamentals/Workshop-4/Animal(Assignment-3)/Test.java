/**
 @author: Tabrej Mujawar
 Assignment: Create classes and interfaces as shown in the diagram below and test your code
 Class: Test
**/
package com.animal;

public class Test {

	public static void main(String[] args) {
		 
		System.out.println("Spider details : ");
		Animal spider=new Spider();
		spider.eat();
		System.out.println();
		
	   System.out.println("Cat details : ");
	   Cat cat=new Cat("ABC");
	   System.out.println("Cat name = "+cat.getName());
	   cat.setName("Snowbell");
	   System.out.println("New cat name = "+cat.getName());
	   cat.play();
	   cat.eat();
	   System.out.println();
	   
	   System.out.println("Fish details : ");
	   Fish fish=new Fish("PQR");
	   System.out.println("Fish name = "+fish.getName());
	   fish.setName("Dolphin");
	   System.out.println("New fish name = "+fish.getName());
	   fish.play();
	   fish.walk();
	   fish.eat();
	  
	   
	   
	   
	   
			

	

}
}