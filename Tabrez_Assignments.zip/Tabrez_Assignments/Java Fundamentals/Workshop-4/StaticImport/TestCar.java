/**
 @author: Tabrej Mujawar
 Assignment: WAP to demonstrate the concept of static import.
 Class: TestCar
**/
package com.cybage.workshop4;
import static com.cybage.workshop4.Car.*;

import java.util.Scanner;

public class TestCar {

	public static void main(String[] args) {
	      
		  System.out.println("Enter distance(in km) and time(in hours) to calculate speed of car");
		  Scanner sc=new Scanner(System.in);
		 
		  double speed=calculateSpeed(sc.nextDouble(),sc.nextDouble());
		  System.out.println("Speed of car = "+speed);

	}

}
