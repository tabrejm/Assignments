/**
 @author: Tabrej Mujawar
 Assignment: WAP to demonstrate the concept of static import.
 Class: Car
**/
package com.cybage.workshop4;

public class Car {
	
       public static double calculateSpeed(double distance,double time)
       {
    	   return (distance/time);
       }
       
 

}
