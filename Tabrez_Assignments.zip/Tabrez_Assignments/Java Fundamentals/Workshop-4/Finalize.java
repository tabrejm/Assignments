/**
 @author: Tabrej Mujawar
 Assignment: WAP to demonstrate the concept of finalize() method.
 Class: Finalize
**/
package com.cybage.workshop4;

public class Finalize {

	public static void main(String[] args) {
		
		  Finalize object=new Finalize();
		  object=null;
		  System.gc();
		  
		  System.out.println("Main method ends.");
	}
	
	protected void finalize()
	{
		System.out.println("Finalize method called");
	}

}
