package com.cybage.examples;

public class HelloWorld {

	public static void main(String[] args) {
		
		int a=10;
		char c='A';
		String s="Welcome";
		byte b=4;
		double d=25.45;
		float f=50.25F;
		
		int h=b;
		
		double v=a;
		
		double k=(double)f;
		
	}

}
