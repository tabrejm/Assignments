package com.cybage.examples;

import java.lang.reflect.Array;
import java.util.Arrays;

public class FibonacciSum {

	public int sumEvenFibonacccisum(int n)
	{
		int sum=0;
		int arr[]=new int[n];
		int n1=0;
		int n2=1;
		arr[0]=0;
		arr[1]=1;
		for(int i=2;i<n;i++)
		{
			int n3=n1+n2;
			arr[i]=n3;
			n1=n2;
			n2=n3;
			
		}
		
		for(int a:arr)
		{
			if(a%2==0)
			{
				sum=sum+a;
			}
		}
		return sum;
		
	}

	public static void main(String[] args) {
		
		FibonacciSum f=new FibonacciSum();
		System.out.println(f.sumEvenFibonacccisum(10));
		
	}

}
