package com.cybage.examples;

public class Structure {

	public static void main(String[] args) {
		int c=1;
		boolean flag=false;
		for(int i=0;i<5;i++)
		{
			
			for(int j=1;j<=c;j++)
			{
			System.out.print("*");
			}
			if(c>=5 || flag==true)
			{
				c=c-2;
				flag=true;
			}
			if(!flag)
			{
			c=c+2;
			}
			System.out.println();
		}

	}

}
