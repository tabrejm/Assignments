package day3;

public class RuntimePolymorphism {

	  class Employee
	  {
		  int   id;
		  String name;
		  String location;
		  
		 public Employee()
		 {
			 System.out.println("In Employee class");
		 }
		 
		 public Employee(int id, String name, String location) {	
				this.id = id;
				this.name = name;
				this.location = location;
			}
		 
		 public String getDetails()
		 {
			 return "Employee detail :  \n Id = "+id+" \n "+"Name = "+name+"\n"+"Location = "+location+"\n";
		 }

		  
	  }
	  
	  class Manager extends Employee
	  {
		  String department;
		  String project;
		  
		  public Manager() {
			System.out.println("In Manager class");
		}

		public Manager(int id, String name, String location,String department, String project) {
			super(id,name,location);
			this.department = department;
			this.project = project;
		}

		//Implementing runtime polymorphism by using function overriding 
		@Override
		public String getDetails() {
			 return "Manager detail :  \n Id = "+id+" \n "+"Name = "+name+"\n"+"Location = "+location+"\n"+"Department = "+department+"\n"+"Project = "+project+"\n";
		}
		  
		  
		  
	  }
	
	public static void main(String[] args) {
		   RuntimePolymorphism r=new RuntimePolymorphism();
		   Employee e=r.new Employee(1,"A","Pune");
		   Manager m=r.new Manager(2,"M","Mumbai","Software Development","Ecommerce");
		   System.out.println(e.getDetails());
		   System.out.println(m.getDetails());
		   

	}

}
