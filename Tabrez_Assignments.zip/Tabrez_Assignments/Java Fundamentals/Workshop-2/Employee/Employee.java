package day3;

public class Employee {
	
	    int empno;
	    String ename;
	    String address;
	    int contactNo;
	    
		public Employee(int empno, String ename, String address, int contactNo) {
			this.empno = empno;
			this.ename = ename;
			this.address = address;
			this.contactNo = contactNo;
		}

		@Override
		public String toString() {
			return "Employee [empno=" + empno + ", ename=" + ename + ", address=" + address + ", contactNo=" + contactNo
					+ "]";
		}
	    
	    

}
