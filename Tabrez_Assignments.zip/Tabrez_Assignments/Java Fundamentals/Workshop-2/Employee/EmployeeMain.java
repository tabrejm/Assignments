package day3;

public class EmployeeMain {

	public static void main(String[] args) {
		
		 Employee[] emp=new Employee[5];
		 emp[0]=new Employee(1,"A","Pune",32345);
		 emp[1]=new Employee(2,"B","Mumbai",52345);
		 emp[2]=new Employee(3,"C","Bangalore",22345);
		 emp[3]=new Employee(4,"D","Pune",72345);
		 emp[4]=new Employee(5,"E","Hyderabad",12345);
		 
		 Manager[] m=new Manager[2];
		 m[0]=new Manager(45,"K","Pune",96542,"Software Development",10);
		 m[1]=new Manager(55,"N","Mumbai",46542,"QA",15);
		 
		 for(int i=0;i<emp.length;i++)
		 {
			 System.out.println(emp[i].toString());
		 }
		 
		 for(int j=0;j<m.length;j++)
		 {
			 System.out.println(m[j].toString());
		 }
		 

	}

}
