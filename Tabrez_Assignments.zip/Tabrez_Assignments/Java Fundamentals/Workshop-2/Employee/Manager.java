package day3;

public class Manager extends Employee {
	
	     String department;
	     int number_of_reportees;
	     
		public Manager(int empno, String ename, String address, int contactNo, String department,
				int number_of_reportees) {
			super(empno, ename, address, contactNo);
			this.department = department;
			this.number_of_reportees = number_of_reportees;
		}

		@Override
		public String toString() {
			return "Manager [department=" + department + ", number_of_reportees=" + number_of_reportees + ", empno="
					+ empno + ", ename=" + ename + ", address=" + address + ", contactNo=" + contactNo + "]";
		}

	
	     
		
	     

}
