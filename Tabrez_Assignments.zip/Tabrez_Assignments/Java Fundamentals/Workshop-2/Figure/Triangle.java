package day3;

public class Triangle extends Figure
{

	public Triangle(double a,double b) {
		super(a,b);
		
	}
	
	@Override
	public void  Area()
	{
		 
	     System.out.println("Area of Triangle = "+(0.5*a*b));
	     
	}
	
	
}