package day3;

public class Rectangle extends Figure{
	

	public Rectangle(double a, double b) {
		super(a, b);
		
	}
	
	@Override
	public void  Area()
	{
		 
	     System.out.println("Area of Rectangle = "+(a* b));
	     
	}

}
