package day3;

public class Main {

	public static void main(String[] args) {

	
			   Figure f1=new Rectangle(10,20);
			   f1.Area();
			   Figure f2=new Triangle(20,40);
			   f2.Area();
			
			
			
		
	}

}
