package day3;


 public class Figure {
	
	   double a;
	   double b;
	   
	   
	
	
  public Figure(double a, double b) {
		
		this.a = a;
		this.b = b;
		
	}
	  
	public void  Area()
	{
	     System.out.println("Area");
	}
	


	
	
	

}


