package day3;

public class Book {
	int isbn; 
	String title; 
	double price;
	
	public Book(int isbn, String title, double price) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}
	
	
       

}
