package day3;

public class BookMain {

	public static void main(String[] args) {
		
		Book b1=new Magazine(1,"A",500,"Business");
		Book b2=new Novel(2,"B",400,"pqr");
		System.out.println(b1.toString());
		System.out.println(b2.toString());
		
		
	}

}
