package day3;

public class MainCalculater {

	public static void main(String[] args) {
		
		Calculater c=new Calculater(50,25);
		System.out.println(c.Add());
		System.out.println(c.Substract());
		System.out.println(c.Multiply());
		System.out.println(c.Divide());
		
		ScientificCalculater sc=new ScientificCalculater(5,10,15);
		System.out.println(sc.ModValue());

		

	}

}
