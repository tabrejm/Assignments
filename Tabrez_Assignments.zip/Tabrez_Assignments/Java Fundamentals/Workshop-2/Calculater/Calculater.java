package day3;

public class Calculater {
	
	  double num1;
	  double num2;
	  double result;
	
	public Calculater(double num1, double num2) {
		this.num1 = num1;
		this.num2 = num2;
	}
	public double Add()
	{
		result= num1+num2;
		return result;
	}
	
	public double Substract()
	{
		result= num1-num2;
		return result;
		
	}
	
	public double Divide()
	{
		result= num1/num2;
		return result;
	}
	
	public double Multiply()
	{
		result= num1*num2;
		return result;
	}
	
	  
	  

}
