package day3;

public class Student {
	
	   private int studentId;
	   private String name;
	   private int contactNo;
	   private String course;
	   private double fees;
	   
	public Student(int studentId, String name, int contactNo, String course, double fees) {
		
		this.studentId = studentId;
		this.name = name;
		this.contactNo = contactNo;
		this.course = course;
		this.fees = fees;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", contactNo=" + contactNo + ", course=" + course
				+ ", fees=" + fees + "]";
	}
	
	
	public static void main(String[] args)
	{
		Student[] stud=new Student[5];
		stud[0]=new Student(1,"abc",12345,"A",5000);
		stud[1]=new Student(2,"pqr",42345,"B",7000);
		stud[2]=new Student(3,"acc",12345,"C",4000);
	    stud[3]=new Student(4,"jkl",12345,"D",10000);
		stud[4]=new Student(5,"lmn",12345,"E",6000);
		
		double sum=0;
		for(int i=0;i<stud.length;i++)
		{
			System.out.println(stud[i].toString());
			sum=sum+stud[i].getFees();
		}
		
		System.out.println("Total fees of all students = "+sum);
		
		  
		
		
	}
	
	   
	   

}
