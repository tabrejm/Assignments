$(document).ready(function() {
    $('.content').richText();
});