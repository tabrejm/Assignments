/****Add comment****/
function Addcomment(id) {
    var blogId = sessionStorage.getItem('blogId');
    var comment = document.getElementById('commentBox').value;
    let username = sessionStorage.getItem('email');
    var dt = new Date();
    var time = new Date().toDateString() + "  " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();

    var commentObj = { "username": username, "comment": comment, "time": time };
    commentList.push(commentObj);

    var data1 = '{"comments": ' + JSON.stringify(commentList) + '}';

    $.ajax({
        type: "PATCH",
        url: "http://localhost:3000/post_db/" + blogId,
        async: true,
        processData: false,
        data: data1,
        dataType: "json",
        contentType: 'application/json',
        success: function(data) {

            console.log(data);
        },
        error: function() {
            alert(":x: Comment Failed");
        },
    });


}

var commentList = [];
var content = null;
window.onload = (event) => {
    let email = sessionStorage.getItem('email');

    console.log(email);


    if (email == "undefined" || email == "" || email == null) {
        window.location.replace("./login.html");

    } else {
        document.getElementById('username').innerHTML = email;
        console.log("PAGE LOADED SUCCESSFULLY");
    }



    var blogId = sessionStorage.getItem('blogId');


    document.getElementById('LikeCountVar').innerText = "";

    $.ajax({
        type: "Get",
        url: "http://localhost:3000/post_db/" + blogId,
        dataType: "json",
        success: function(data) {
            console.log(data);
            $('#blogTitle').html(data.blogTitle);
            $('#blogData').html(data.blogData);
            var src = data.image;
            $("#image").attr("src", src);

            var Likecounts = sessionStorage.getItem('LikeCountVar');
            document.getElementById('LikeCountVar').innerText = Likecounts;




            console.log(data);
            if (!(data.comments == "undefined" || data.comments == "" || data.comments == null || data.comments.length == 0)) {
                content = data;
                console.log(content);
                commentList = data.comments;
                console.log(commentList);
                var div = "";
                for (var i in commentList) {
                    div += `<div>
                    <h4><i class="fa fa-user-circle" style="color:black" aria-hidden="true"></i>   ${commentList[i].username}</h4>
                    <p style="margin:20px;"> <i class="fa fa-comments " aria-hidden="true"></i> ${commentList[i].comment}</p>
                    <div class="col p-0 d-flex justify-content-end align-items-end"><i class="fa fa-clock-o " style="font-size:1.5vw;" aria-hidden="true"></i> ${commentList[i].time}</div><hr>
                    </div>`

                }

                $('#cmts').html(div);

            } else {
                $('#cmts').html(`<h2>No Comments</h2>`);
            }


            var divModal = "";
            for (var i in data.like) {

                divModal += `<div class="bg-light m-2 p-3 rounded-pill shadow
                ">${data.like[i]}</div><hr>`
            }

            if (Likecounts > 0) {
                document.getElementById('modalBody').innerHTML = divModal;
            }


        }
    });

};

function Add() {
    window.location = "./addpost.html";
}

var Home = function() {
    window.location = "./userpage.html";
}
var logout = function() {
    sessionStorage.removeItem('email');
    window.location.replace('./login.html');

}