function AddPost() {
    $('.content').unRichText();

    var content = document.getElementById('text1').value;
    var title = document.getElementById('title').value;
    var categoryId = document.getElementById('categoryId').value;
    var imageURL = document.getElementById('imageURL').value;
    var dt = new Date();
    var time = new Date().toDateString() + "  " + dt.getHours() + ":" + dt.getMinutes() + ":" + dt.getSeconds();
    // var like = [];


    var data = {

        "image": imageURL,
        "blogTitle": title,
        "blogData": content,
        "like": [],
        "comments": [],
        "categoryId": categoryId,
        "timestamp": time

    };
    $.post("http://localhost:3000/post_db", data).done(function() {
        window.location = "./userpage.html";
    });


    // $.ajax({
    //     type: "POST",
    //     url: "http://localhost:3000/post_db",
    //     async: true,
    //     processData: false,
    //     data: data1,
    //     dataType: "json",
    //     contentType: 'application/json',
    //     success: function(data) {

    //         console.log(data);
    //         window.location = "./userpage.html";
    //     },
    //     error: function() {
    //         alert(":x:POST Failed");
    //     },
    // });
}


window.onload = (event) => {
    let username = sessionStorage.getItem('email');

    if (username == "undefined" || username == "" || username == null) {
        window.location.replace("./login.html");

    } else {
        document.getElementById('username').innerHTML = username;
        console.log("PAGE LOADED SUCCESSFULLY");
    }
};

var Home = function() {
    window.location = "./userpage.html";
}
var logout = function() {
    sessionStorage.removeItem('email');
    window.location.replace('./login.html');

}