var contents = {};
window.onload = (event) => {
    let email = sessionStorage.getItem('email');
    let username = sessionStorage.getItem('username');
    console.log(email);


    if (email == "undefined" || email == "" || email == null) {
        window.location.replace("./login.html");

    } else {
        document.getElementById('username').innerHTML = email;
        console.log("PAGE LOADED SUCCESSFULLY");
    }

    $.ajax({
        type: "Get",
        url: "http://localhost:3000/post_db",
        dataType: "json",
        success: function(data) {
            contents = data;

            var div = "";

            for (var i in data) {
                let color = "black";
                let title = "Unlike";
                var index = -1;
                var LikeCount = 0;
                if ((data[i].like == "undefined" || data[i].like == null || data[i].like == "")) {

                    LikeCount = 0;


                } else {

                    LikeCount = data[i].like.length;

                    index = data[i].like.indexOf(username);
                    if (index != -1) {
                        color = "#3389FF";
                        title = "Liked By you";
                    } else {
                        color = "black";
                        title = "Unlike";
                    }

                }
                console.log(data[i]);

                var likeId = "l" + data[i].id;
                div += `
                <div class="col " id="${data[i].id}">

                <div class="card " style="width:32rem;">
                    <img class="image" alt="..." src="${data[i].image}" style="height:20rem;" />
                    <div class="card-body p-3" style="height:25rem;">
                        <h4><b>${data[i].blogTitle}</b></h4>

                        <p class="blog-data" style="color: gray;font-size: 12px;font-weight: 100;">
                            ${data[i].blogData.slice(0, 200)}... <button  type="button"  onclick="Readmore(${data[i].id})"
                                style="outline: none;border: none;text-decoration: none; color:black;background-color: white;font-weight:bold;">
                                Read more..
                            </button> </p>

                        <span>
                            <div class="row ">
                                <div class="col-3 p-0 mt-3">

                                    <button onclick="LikeMe(${data[i].id})" class="fa fa-thumbs-o-up fa-2x "data-bs-toggle="tooltip" data-bs-placement="top" title="${title}"
                                        style="outline: none;border: none;color:${color};text-decoration: none;text-transform: none;background-color: white;margin-left:1rem;">
                                        <span id="${likeId}">${LikeCount} </span>
                                    </button>


                                </div>
                                <div class="row ">
                                    <div class="col p-0 d-flex justify-content-end align-items-center">
                                        <div> <b>Date : </b></div>
                                        <div> ${data[i].timestamp}</div>
                                    </div>
                                </div>

                            </div>
                        </span>


                    </div>
                </div>
            </div>`


            }
            document.getElementById('container12').innerHTML = div;

        }
    });

    /****************CATEGORY FUNCTIONALITY********************/
    const categoryTitle = document.querySelectorAll('.category-title');

    for (let k = 0; k < categoryTitle.length; k++) {
        categoryTitle[k].addEventListener('click', filterPosts.bind(this, categoryTitle[k]));

    }


    function filterPosts(item) {

        $.ajax({
            type: "Get",
            url: "http://localhost:3000/post_db",
            dataType: "json",
            success: function(data) {


                for (let j = 0; j < data.length; j++) {
                    var postId = data[j].categoryId;
                    console.log(postId);
                    var itemId = item.innerHTML;

                    console.log(itemId);

                    if (postId == itemId) {
                        console.log('>>>>>>>>>>>>>>');
                        let div = "";
                        for (var i in data) {
                            let color = "black";
                            var LikeCount = 0;
                            if (!(data[i].like == "undefined" || data[i].like == null || data[i].like == "")) {


                                LikeCount = data[i].like.length;
                                if (LikeCount > 0) {
                                    color = "#3389FF";
                                }
                            }
                            console.log(JSON.stringify(data));
                            if (postId == data[i].categoryId) {


                                var likeId = "l" + data[i].id;
                                div += `
                <div class="col"  id="${data[i].id}">
     
                <div class="card " style="width:32rem;">
                <img class="image" alt="..." src="${data[i].image}"  style="height:20rem;"/>
                <div class="card-body p-3" style="height:25rem;">
              <h4><b>${data[i].blogTitle}</b></h4>
            
              <p class="blog-data" style="color: gray;font-size: 12px;font-weight: 100;">
              ${data[i].blogData.slice(0, 200)}... <button onclick="Readmore(${data[i].id})"  
              style="outline: none;border: none;text-decoration: none; color:black;background-color: white;font-weight:bold;">
             Read more..
            </button> </p>
           
              <span>
                <div class="row ">
                  <div class="col-3 p-0 ">

                    <button onclick="LikeMe(${data[i].id})" class="fa fa-thumbs-o-up fa-2x " 
                      style="outline: none;border: none;color:${color};text-decoration: none;text-transform: none;background-color: white;margin-left:1rem;">
                      <span  id="${likeId}">${LikeCount} </span>
                    </button>
              
                  
                  </div>
                  <div class="row ">
                  <div class="col p-0 d-flex justify-content-end align-items-center">
                 <div> <b>Date : </b></div><div>  ${data[i].timestamp}</div>
                  </div>
                  </div>  
                
            </div>
        </span>
           </div>
            </div>
           </div>`


                            }
                        }
                        document.getElementById('container12').innerHTML = div;

                    }
                }

            }
        });

    }

};

function Add() {
    window.location = "./addpost.html";
}

/************LIKE FUNCTIONALITY******************** */
let LikeMe = function(id) {
    var likeArray = [];

    for (var i in contents) {
        if (contents[i].id == id) {
            if (contents[i].like == "undefined" || contents[i].like == null || contents[i].like == "") {
                likeArray = [];
            } else {
                likeArray = contents[i].like;
            }
            break;
        }
    }

    var LikeFlag = false;
    var LikeCountVar = likeArray.length;

    var btnElement = "l" + id;
    console.log(btnElement)

    for (var i in likeArray) {
        if (likeArray[i] == sessionStorage.getItem('username')) {

            LikeFlag = true;
            likeArray.splice(i, 1);
        }


    }
    if (LikeFlag) {

        LikeCountVar--;
        document.getElementById(btnElement).parentNode.style.color = "black";
        document.getElementById(btnElement).value = "Unlike";



    } else {
        LikeCountVar++;
        likeArray.push(sessionStorage.getItem('username'));
        document.getElementById(btnElement).parentNode.style.color = "#3389FF";
        document.getElementById(btnElement).value = "Liked By you";


    }

    document.getElementById(btnElement).innerText = LikeCountVar;
    sessionStorage.setItem('LikeCountVar', LikeCountVar);





    var LikeJSON = '{ "like": ' + JSON.stringify(likeArray) + '}';


    $.ajax({
        type: "PATCH",
        url: "http://localhost:3000/post_db/" + id,
        async: true,
        processData: false,
        data: LikeJSON,
        contentType: 'application/json',
        success: function(data) {
            console.log(data);
        },
        error: function() {
            alert(":x: Comment Failed");
        },
    });




}




function Readmore(id) {
    sessionStorage.setItem('blogId', id);
    window.location = "./readmore.html";
}


var Home = function() {
    window.location = "./userpage.html";
}
var logout = function() {
    sessionStorage.removeItem('email');
    window.location.replace('./login.html');

}