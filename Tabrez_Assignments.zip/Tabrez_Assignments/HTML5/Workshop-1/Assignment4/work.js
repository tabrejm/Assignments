var j=1;
function countNumbers()
{
     if(j<1000)
     {
        j=j+1;
        postMessage(j);
     }
  setTimeout("countNumbers()",500);
}
new countNumbers();